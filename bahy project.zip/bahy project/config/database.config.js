module.exports = {
    url:'mongodb+srv://admin:admin321@learning.eauwn.mongodb.net/ecommerce-api?retryWrites=true&w=majority'
}